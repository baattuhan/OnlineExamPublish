/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'ca', {
	copy: 'Copyright &copy; $1. Tots els drets reservats.',
	dlgTitle: 'Quant al CKEditor 4',
	moreInfo: 'Per informació sobre llicències visiteu el nostre lloc web:'
} );
