/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'bidi', 'vi', {
	ltr: 'Văn bản hướng từ trái sang phải',
	rtl: 'Văn bản hướng từ phải sang trái'
} );
