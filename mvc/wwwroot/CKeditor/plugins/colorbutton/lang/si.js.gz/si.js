﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colorbutton', 'si', {
	auto: 'Automatic', // MISSING
	bgColorTitle: 'පසුබිම් වර්ණය',
	colors: {
		'000': 'Black', // MISSING
		'800000': 'Maroon', // MISSING
		'8B4513': 'Saddle Brown', // MISSING
		'2F4F4F': 'Dark Slate Gray', // MISSING
		'008080': 'Teal', // MISSING
		'000080': 'Navy', // MISSING
		'4B0082': 'Indigo', // MISSING
		'696969': 'Dark Gray', // MISSING
		B22222: 'Fire Brick', // MISSING
		A52A2A: 'Brown', // MISSING
		DAA520: 'Golden Rod', // MISSING
		'006400': 'Dark Green', // MISSING
		'40E0D0': 'Turquoise', // MISSING
		'0000CD': 'Medium Blue', // MISSING
		'800080': 'Purple', // MISSING
		'808080': 'Gray', // MISSING
		F00: 'Red', // MISSING
		FF8C00: 'Dark Orange', // MISSING
		FFD700: 'Gold', // MISSING
		'008000': 'Green', // MISSING
		'0FF': 'Cyan', // MISSING
		'00F': 'Blue', // MISSING
		EE82EE: 'Violet', // MISSING
		A9A9A9: 'Dim Gray', // MISSING
		FFA07A: 'Light Salmon', // MISSING
		FFA500: 'Orange', // MISSING
		FFFF00: 'Yellow', // MISSING
		'00FF00': 'Lime', // MISSING
		AFEEEE: 'Pale Turquoise', // MISSING
		ADD8E6: 'Light Blue', // MISSING
		DDA0DD: 'Plum', // MISSING
		D3D3D3: 'Light Grey', // MISSING
		FFF0F5: 'Lavender Blush', // MISSING
		FAEBD7: 'Antique White', // MISSING
		FFFFE0: 'Light Yellow', // MISSING
		F0FFF0: 'Honeydew', // MISSING
		F0FFFF: 'Azure', // MISSING
		F0F8FF: 'Alice Blue', // MISSING
		E6E6FA: 'Lavender', // MISSING
		FFF: 'White', // MISSING
		'1ABC9C': 'Strong Cyan', // MISSING
		'2ECC71': 'Emerald', // MISSING
		'3498DB': 'Bright Blue', // MISSING
		'9B59B6': 'Amethyst', // MISSING
		'4E5F70': 'Grayish Blue', // MISSING
		'F1C40F': 'Vivid Yellow', // MISSING
		'16A085': 'Dark Cyan', // MISSING
		'27AE60': 'Dark Emerald', // MISSING
		'2980B9': 'Strong Blue', // MISSING
		'8E44AD': 'Dark Violet', // MISSING
		'2C3E50': 'Desaturated Blue', // MISSING
		'F39C12': 'Orange', // MISSING
		'E67E22': 'Carrot', // MISSING
		'E74C3C': 'Pale Red', // MISSING
		'ECF0F1': 'Bright Silver', // MISSING
		'95A5A6': 'Light Grayish Cyan', // MISSING
		'DDD': 'Light Gray', // MISSING
		'D35400': 'Pumpkin', // MISSING
		'C0392B': 'Strong Red', // MISSING
		'BDC3C7': 'Silver', // MISSING
		'7F8C8D': 'Grayish Cyan', // MISSING
		'999': 'Dark Gray' // MISSING
	},
	more: 'More Colors...', // MISSING
	panelTitle: 'වර්ණය',
	textColorTitle: 'අක්ෂර වර්ණ'
} );
