/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'es', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Título',
	cssClassInputLabel: 'Clase de hoja de estilos',
	edit: 'Editar Div',
	inlineStyleInputLabel: 'Estilo',
	langDirLTRLabel: 'Izquierda a Derecha (LTR)',
	langDirLabel: 'Orientación',
	langDirRTLLabel: 'Derecha a Izquierda (RTL)',
	languageCodeInputLabel: ' Codigo de idioma',
	remove: 'Quitar Div',
	styleSelectLabel: 'Estilo',
	title: 'Crear contenedor DIV',
	toolbar: 'Crear contenedor DIV'
} );
