/**
 * @license Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.plugins.setLang( 'placeholder', 'ug', {
	title: 'ئورۇن بەلگە خاسلىقى',
	toolbar: 'ئورۇن بەلگە قۇر',
	name: 'ئورۇن بەلگە ئىسمى',
	invalidName: 'ئورۇن ئىگىلەش بەلگىسىنى قۇرۇق قۇيۇشقا بولمايدۇ ، مەزمۇنىغا كىرگۈزۈشكە بولمايدىغان بەلگىلەر :  [, ], <, >',
	pathName: 'ئورۇن ئىگىلەش بەلگىسى'
} );
