/**
 * @license Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.plugins.setLang( 'placeholder', 'sq', {
	title: 'Karakteristikat e Mbajtësit të Vendit',
	toolbar: 'Krijo Mabjtës Vendi',
	name: 'Emri i Hapësirës',
	invalidName: 'Hapësira nuk mund të jetë e zbrazët dhe nuk mund të përmbajë asnjë nga karakteret: [, ], <, >',
	pathName: 'hapësira'
} );
