/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'smiley', 'bg', {
	options: 'Опции за усмивка',
	title: 'Вмъкване на усмивка',
	toolbar: 'Усмивка'
} );
