/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'smiley', 'is', {
	options: 'Smiley Options', // MISSING
	title: 'Velja svip',
	toolbar: 'Svipur'
} );
