/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image', 'hu', {
	alt: 'Alternatív szöveg',
	border: 'Keret',
	btnUpload: 'Küldés a szerverre',
	button2Img: 'Szeretne a kiválasztott képgombból sima képet csinálni?',
	hSpace: 'Vízsz. táv',
	img2Button: 'Szeretne a kiválasztott képből képgombot csinálni?',
	infoTab: 'Alaptulajdonságok',
	linkTab: 'Hivatkozás',
	lockRatio: 'Arány megtartása',
	menu: 'Kép tulajdonságai',
	resetSize: 'Eredeti méret',
	title: 'Kép tulajdonságai',
	titleButton: 'Képgomb tulajdonságai',
	upload: 'Feltöltés',
	urlMissing: 'Hiányzik a kép URL-je.',
	vSpace: 'Függ. táv',
	validateBorder: 'A keret méretének egész számot kell beírni!',
	validateHSpace: 'Vízszintes távolságnak egész számot kell beírni!',
	validateVSpace: 'Függőleges távolságnak egész számot kell beírni!'
} );
