/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image', 'zh', {
	alt: '替代文字',
	border: '框線',
	btnUpload: '傳送到伺服器',
	button2Img: '請問您確定要將「圖片按鈕」轉換成「圖片」嗎？',
	hSpace: 'HSpace',
	img2Button: '請問您確定要將「圖片」轉換成「圖片按鈕」嗎？',
	infoTab: '影像資訊',
	linkTab: '連結',
	lockRatio: '固定比例',
	menu: '影像屬性',
	resetSize: '重設大小',
	title: '影像屬性',
	titleButton: '影像按鈕屬性',
	upload: '上傳',
	urlMissing: '遺失圖片來源之 URL ',
	vSpace: 'VSpace',
	validateBorder: '框線必須是整數。',
	validateHSpace: 'HSpace 必須是整數。',
	validateVSpace: 'VSpace 必須是整數。'
} );
