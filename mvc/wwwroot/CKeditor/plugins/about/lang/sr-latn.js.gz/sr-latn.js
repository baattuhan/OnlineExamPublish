/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'sr-latn', {
	copy: 'Copyright &copy; $1. Sva prava zadržana.',
	dlgTitle: 'O CKEditor 4',
	moreInfo: 'Za informacije o licenci posetite našu web stranicu:'
} );
