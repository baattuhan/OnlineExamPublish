/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'el', {
	confirmCleanup: 'Το κείμενο που επικολλάται φαίνεται να είναι αντιγραμμένο από το Word. Μήπως θα θέλατε να καθαριστεί προτού επικολληθεί;',
	error: 'Δεν ήταν δυνατό να καθαριστούν τα δεδομένα λόγω ενός εσωτερικού σφάλματος',
	title: 'Επικόλληση από το Word',
	toolbar: 'Επικόλληση από το Word'
} );
