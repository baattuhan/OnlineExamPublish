/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'zh-cn', {
	confirmCleanup: '您要粘贴的内容好像是来自 MS Word，是否要清除 MS Word 格式后再粘贴？',
	error: '由于内部错误无法清理要粘贴的数据',
	title: '从 MS Word 粘贴',
	toolbar: '从 MS Word 粘贴'
} );
