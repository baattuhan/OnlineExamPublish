/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'el', {
	toolbarCollapse: 'Σύμπτυξη Εργαλειοθήκης',
	toolbarExpand: 'Ανάπτυξη Εργαλειοθήκης',
	toolbarGroups: {
		document: 'Έγγραφο',
		clipboard: 'Πρόχειρο/Αναίρεση',
		editing: 'Επεξεργασία',
		forms: 'Φόρμες',
		basicstyles: 'Βασικά Στυλ',
		paragraph: 'Παράγραφος',
		links: 'Σύνδεσμοι',
		insert: 'Εισαγωγή',
		styles: 'Στυλ',
		colors: 'Χρώματα',
		tools: 'Εργαλεία'
	},
	toolbars: 'Εργαλειοθήκες επεξεργαστή'
} );
