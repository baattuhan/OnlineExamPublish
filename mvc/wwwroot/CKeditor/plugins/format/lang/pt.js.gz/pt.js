/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'pt', {
	label: 'Formatar',
	panelTitle: 'Formatar Parágrafo',
	tag_address: 'Endereço',
	tag_div: 'Normal (DIV)',
	tag_h1: 'Título 1',
	tag_h2: 'Título 2',
	tag_h3: 'Título 3',
	tag_h4: 'Título 4',
	tag_h5: 'Título 5',
	tag_h6: 'Título 6',
	tag_p: 'Normal',
	tag_pre: 'Formatado'
} );
