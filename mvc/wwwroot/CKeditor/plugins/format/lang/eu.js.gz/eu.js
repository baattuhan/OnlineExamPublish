/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'eu', {
	label: 'Formatua',
	panelTitle: 'Paragrafoaren formatua',
	tag_address: 'Helbidea',
	tag_div: 'Normala (DIV)',
	tag_h1: 'Izenburua 1',
	tag_h2: 'Izenburua 2',
	tag_h3: 'Izenburua 3',
	tag_h4: 'Izenburua 4',
	tag_h5: 'Izenburua 5',
	tag_h6: 'Izenburua 6',
	tag_p: 'Normala',
	tag_pre: 'Formatuduna'
} );
