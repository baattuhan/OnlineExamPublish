/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'uk', {
	label: 'Форматування',
	panelTitle: 'Форматування параграфа',
	tag_address: 'Адреса',
	tag_div: 'Нормальний (div)',
	tag_h1: 'Заголовок 1',
	tag_h2: 'Заголовок 2',
	tag_h3: 'Заголовок 3',
	tag_h4: 'Заголовок 4',
	tag_h5: 'Заголовок 5',
	tag_h6: 'Заголовок 6',
	tag_p: 'Нормальний',
	tag_pre: 'Форматований'
} );
