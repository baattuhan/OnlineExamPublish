/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'it', {
	label: 'Formato',
	panelTitle: 'Formato',
	tag_address: 'Indirizzo',
	tag_div: 'Paragrafo (DIV)',
	tag_h1: 'Titolo 1',
	tag_h2: 'Titolo 2',
	tag_h3: 'Titolo 3',
	tag_h4: 'Titolo 4',
	tag_h5: 'Titolo 5',
	tag_h6: 'Titolo 6',
	tag_p: 'Normale',
	tag_pre: 'Formattato'
} );
