/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'sv', {
	label: 'Teckenformat',
	panelTitle: 'Teckenformat',
	tag_address: 'Adress',
	tag_div: 'Normal (DIV)',
	tag_h1: 'Rubrik 1',
	tag_h2: 'Rubrik 2',
	tag_h3: 'Rubrik 3',
	tag_h4: 'Rubrik 4',
	tag_h5: 'Rubrik 5',
	tag_h6: 'Rubrik 6',
	tag_p: 'Normal',
	tag_pre: 'Formaterad'
} );
