/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'mk', {
	label: 'Format', // MISSING
	panelTitle: 'Paragraph Format', // MISSING
	tag_address: 'Address', // MISSING
	tag_div: 'Normal (DIV)', // MISSING
	tag_h1: 'Heading 1', // MISSING
	tag_h2: 'Heading 2', // MISSING
	tag_h3: 'Heading 3', // MISSING
	tag_h4: 'Heading 4', // MISSING
	tag_h5: 'Heading 5', // MISSING
	tag_h6: 'Heading 6', // MISSING
	tag_p: 'Normal', // MISSING
	tag_pre: 'Formatted' // MISSING
} );
