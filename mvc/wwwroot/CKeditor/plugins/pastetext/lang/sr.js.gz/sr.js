/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'sr', {
	button: 'Залепи као неформиран текст',
	pasteNotification: 'Притисните% 1 да бисте налепили. Претраживач не подржава лепљење помоћу тастера на траци са алаткама или из менија.',
	title: 'Залепи као неформиран текст'
} );
