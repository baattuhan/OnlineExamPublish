/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'pl', {
	button: 'Wklej jako czysty tekst',
	pasteNotification: 'Naciśnij %1 by wkleić tekst. Twoja przeglądarka nie obsługuje wklejania za pomocą przycisku paska narzędzi lub opcji menu kontekstowego.',
	title: 'Wklej jako czysty tekst'
} );
