/**
 * @license Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.plugins.setLang( 'devtools', 'es', {
	title: 'Información del Elemento',
	dialogName: 'Nombre de la ventana de diálogo',
	tabName: 'Nombre de la pestaña',
	elementId: 'ID del Elemento',
	elementType: 'Tipo del elemento'
} );
