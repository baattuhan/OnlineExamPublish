/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'elementspath', 'zh-cn', {
	eleLabel: '元素路径',
	eleTitle: '%1 元素'
} );
