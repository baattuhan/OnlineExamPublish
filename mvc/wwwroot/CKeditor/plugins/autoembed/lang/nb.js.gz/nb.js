/*
 Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'nb', {
	embeddingInProgress: 'Prøver å bygge inn innlimt URL...',
	embeddingFailed: 'URL-en kunne ikke bli automatisk bygget inn.'
} );
