/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'ru', {
	border: 'Показать границы фрейма',
	noUrl: 'Пожалуйста, введите ссылку фрейма',
	scrolling: 'Отображать полосы прокрутки',
	title: 'Свойства iFrame',
	toolbar: 'iFrame',
	tabindex: 'Remove from tabindex' // MISSING
} );
