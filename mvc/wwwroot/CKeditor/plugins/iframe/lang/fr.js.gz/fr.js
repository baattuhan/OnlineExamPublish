/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'fr', {
	border: 'Afficher la bordure du cadre',
	noUrl: 'Veuillez entrer l\'URL du contenu du cadre',
	scrolling: 'Activer les barres de défilement',
	title: 'Propriétés du cadre de contenu incorporé',
	toolbar: 'Cadre de contenu incorporé',
	tabindex: 'Supprimer de tabindex'
} );
