/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'et', {
	border: 'Raami äärise näitamine',
	noUrl: 'Vali iframe URLi liik',
	scrolling: 'Kerimisribade lubamine',
	title: 'IFrame omadused',
	toolbar: 'IFrame',
	tabindex: 'Remove from tabindex' // MISSING
} );
