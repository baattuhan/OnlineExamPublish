/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'ko', {
	options: '특수문자 옵션',
	title: '특수문자 선택',
	toolbar: '특수문자 삽입'
} );
