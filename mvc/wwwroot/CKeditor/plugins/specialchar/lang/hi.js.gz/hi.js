/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'hi', {
	options: 'विशेष चरित्र विकल्प',
	title: 'विशेष करॅक्टर चुनें',
	toolbar: 'विशेष करॅक्टर इन्सर्ट करें'
} );
