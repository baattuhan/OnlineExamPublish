/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'ja', {
	clear: 'クリア',
	highlight: 'ハイライト',
	options: 'カラーオプション',
	selected: '選択された色',
	title: '色選択'
} );
