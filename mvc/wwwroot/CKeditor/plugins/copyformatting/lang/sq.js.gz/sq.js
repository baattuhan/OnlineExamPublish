/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'copyformatting', 'sq', {
	label: 'Kopjo Formatimin',
	notification: {
		copied: 'Formatimi u kopjua',
		applied: 'Formatimi u aplikua',
		canceled: 'Formatimi u ndërpre',
		failed: 'Formatimi dështoi. Nuk mund të aplikosh stile pa i kopjuar fillimisht ato.'
	}
} );
