/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'copyformatting', 'zh-cn', {
	label: '格式刷',
	notification: {
		copied: '格式已复制',
		applied: '格式已应用',
		canceled: '格式已取消',
		failed: '格式化失败，您不能还没复制就应用格式'
	}
} );
