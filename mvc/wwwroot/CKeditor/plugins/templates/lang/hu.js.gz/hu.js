/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'hu', {
	button: 'Sablonok',
	emptyListMsg: '(Nincs sablon megadva)',
	insertOption: 'Kicseréli a jelenlegi tartalmat',
	options: 'Sablon opciók',
	selectPromptMsg: 'Válassza ki melyik sablon nyíljon meg a szerkesztőben<br>(a jelenlegi tartalom elveszik):',
	title: 'Elérhető sablonok'
} );
