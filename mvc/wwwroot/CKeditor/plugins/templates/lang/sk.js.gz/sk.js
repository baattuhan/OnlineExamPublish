/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'sk', {
	button: 'Šablóny',
	emptyListMsg: '(Žiadne šablóny nedefinované)',
	insertOption: 'Nahradiť aktuálny obsah',
	options: 'Možnosti šablóny',
	selectPromptMsg: 'Prosím vyberte šablónu na otvorenie v editore',
	title: 'Šablóny obsahu'
} );
