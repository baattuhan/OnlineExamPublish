/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'pt', {
	button: 'Temas',
	emptyListMsg: '(Sem temas definidos)',
	insertOption: 'Substituir conteúdos atuais',
	options: 'Opções do modelo',
	selectPromptMsg: 'Por favor, selecione o modelo a abrir no editor',
	title: 'Conteúdo dos modelos'
} );
