/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'id', {
	button: 'Contoh',
	emptyListMsg: '(Tidak ada contoh didefinisikan)',
	insertOption: 'Ganti konten sebenarnya',
	options: 'Opsi Contoh',
	selectPromptMsg: 'Mohon pilih contoh untuk dibuka di editor',
	title: 'Contoh Konten'
} );
