/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'he', {
	button: 'תבניות',
	emptyListMsg: '(לא הוגדרו תבניות)',
	insertOption: 'החלפת תוכן ממשי',
	options: 'אפשרויות התבניות',
	selectPromptMsg: 'יש לבחור תבנית לפתיחה בעורך.<br />התוכן המקורי ימחק:',
	title: 'תביות תוכן'
} );
