/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'si', {
	button: 'අච්චුව',
	emptyListMsg: 'කිසිම අච්චුවක් කලින් තීරණය කර ',
	insertOption: 'සත්‍ය අන්තර්ගතයන් ප්‍රතිස්ථාපනය කරන්න',
	options: 'අච්චු ',
	selectPromptMsg: 'කරුණාකර සංස්කරණය සදහා අච්චුවක් ',
	title: 'අන්තර්ගත් අච්චුන්'
} );
