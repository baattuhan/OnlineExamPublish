/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'table', 'sr-latn', {
	border: 'Veličina okvira',
	caption: 'Naslov tabele',
	cell: {
		menu: 'Ćelija',
		insertBefore: 'Ubaci levo',
		insertAfter: 'Ubaci desno',
		deleteCell: 'Obriši ćelije',
		merge: 'Spoj ćelije',
		mergeRight: 'Spolj ćelije desno',
		mergeDown: 'Spolj čelije na dole',
		splitHorizontal: 'Razdvoji ćelije vodoravno',
		splitVertical: 'Razdvoji ćelije uspravno',
		title: 'Karakteristike ćelija',
		cellType: 'Tip ćelija',
		rowSpan: 'Spoj uzdužno',
		colSpan: 'Spoj vodoravno',
		wordWrap: 'Brisanje dugačkih redova',
		hAlign: 'Ravnanje vodoravno',
		vAlign: 'Ravnanje uspravno',
		alignBaseline: 'Bazna linija',
		bgColor: 'Boja pozadine',
		borderColor: 'Boja okvira',
		data: 'Podatak',
		header: 'Zaglavlje',
		columnHeader: 'Column Header', // MISSING
		rowHeader: 'Row Header', // MISSING
		yes: 'Da',
		no: 'Nе',
		invalidWidth: 'U polje širina možete upisati samo brojeve. ',
		invalidHeight: 'U polje visina možete upisati samo brojeve.',
		invalidRowSpan: 'U polje spoj uspravno  možete upistai samo brojeve.',
		invalidColSpan: 'U polje spoj vodoravno možete upistai samo brojeve.',
		chooseColor: 'Izaberi'
	},
	cellPad: 'Razmak ćelija',
	cellSpace: 'Ćelijski prostor',
	column: {
		menu: 'Kolona',
		insertBefore: 'Ubaci levo',
		insertAfter: 'Ubaci desno',
		deleteColumn: 'Obriši kolone'
	},
	columns: 'Kolona',
	deleteTable: 'Izbriši tabelu',
	headers: 'Zaglavlja',
	headersBoth: 'Oba',
	headersColumn: 'Prva kolona',
	headersNone: 'Nema',
	headersRow: 'Prvi red',
	heightUnit: 'Jedinica visine',
	invalidBorder: 'Veličina okvira mora biti broj.',
	invalidCellPadding: 'Padding polja mora biti pozitivan broj.',
	invalidCellSpacing: 'Razmak između ćelija mora biti pozitivan broj.',
	invalidCols: 'Broj kolona mora biti broj veći od 0.',
	invalidHeight: 'Visina tabele mora biti broj.',
	invalidRows: 'Broj redova mora biti veći od 0.',
	invalidWidth: 'Širina tabele mora biti broj.',
	menu: 'Osobine tabele',
	row: {
		menu: 'Red',
		insertBefore: 'Ubaci iznad',
		insertAfter: 'Ubaci ispod',
		deleteRow: 'Obriši redove'
	},
	rows: 'Redovi',
	summary: 'Opis',
	title: 'Karakteristike tabele',
	toolbar: 'Tabela',
	widthPc: 'procenata',
	widthPx: 'piksela',
	widthUnit: 'jedinica za širinu'
} );
