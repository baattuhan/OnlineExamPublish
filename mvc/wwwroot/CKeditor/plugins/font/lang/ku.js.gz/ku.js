/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'font', 'ku', {
	fontSize: {
		label: 'قەبارە',
		voiceLabel: 'قەبارەی فۆنت',
		panelTitle: 'قەبارەی فۆنت'
	},
	label: 'فۆنت',
	panelTitle: 'ناوی فۆنت',
	voiceLabel: 'فۆنت'
} );
