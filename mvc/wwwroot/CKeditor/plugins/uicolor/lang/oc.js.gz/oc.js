/**
 * @license Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.plugins.setLang( 'uicolor', 'oc', {
	title: 'Selector de color',
	options: 'Color Options', // MISSING
	highlight: 'Highlight', // MISSING
	selected: 'Selected Color', // MISSING
	predefined: 'Paletas de colors predefinidas',
	config: 'Pegatz aqueste tèxte dins vòstre fichièr config.js'
} );
