/**
 * @license Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.plugins.setLang( 'uicolor', 'vi', {
	title: 'Giao diện người dùng Color Picker',
	options: 'Color Options', // MISSING
	highlight: 'Highlight', // MISSING
	selected: 'Selected Color', // MISSING
	predefined: 'Tập màu định nghĩa sẵn',
	config: 'Dán chuỗi này vào tập tin config.js của bạn'
} );
