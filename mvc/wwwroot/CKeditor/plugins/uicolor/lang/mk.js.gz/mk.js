/**
 * @license Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.plugins.setLang( 'uicolor', 'mk', {
	title: 'Палета со бои',
	options: 'Color Options', // MISSING
	highlight: 'Highlight', // MISSING
	selected: 'Selected Color', // MISSING
	predefined: 'Предефинирани множества на бои',
	config: 'Залепи го овој текст во config.js датотеката'
} );
