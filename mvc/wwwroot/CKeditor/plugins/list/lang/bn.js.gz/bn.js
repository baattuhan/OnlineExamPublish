/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'list', 'bn', {
	bulletedlist: 'বুলেটেড তালিকা প্রবেশ/অপসারন করি',
	numberedlist: 'সাংখ্যিক লিস্টের লেবেল'
} );
