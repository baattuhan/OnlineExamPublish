/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'list', 'km', {
	bulletedlist: 'បញ្ចូល / លុប​បញ្ជី​ជា​ចំណុច​មូល',
	numberedlist: 'បញ្ចូល / លុប​បញ្ជី​ជា​លេខ'
} );
