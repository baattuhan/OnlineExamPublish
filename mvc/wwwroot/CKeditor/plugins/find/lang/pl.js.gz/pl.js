/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'find', 'pl', {
	find: 'Znajdź',
	findOptions: 'Opcje wyszukiwania',
	findWhat: 'Znajdź:',
	matchCase: 'Uwzględnij wielkość liter',
	matchCyclic: 'Cykliczne dopasowanie',
	matchWord: 'Całe słowa',
	notFoundMsg: 'Nie znaleziono szukanego hasła.',
	replace: 'Zamień',
	replaceAll: 'Zamień wszystko',
	replaceSuccessMsg: '%1 wystąpień zastąpionych.',
	replaceWith: 'Zastąp przez:',
	title: 'Znajdź i zamień'
} );
